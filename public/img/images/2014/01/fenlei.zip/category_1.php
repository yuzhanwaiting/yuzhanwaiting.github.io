<?php
header("Content-type:text/html;charset=utf-8");
class category_1
{
    protected $db,$data=array(),$order_data=array();
    
    function __construct()
    {
        $this->db = new mysqli("localhost","root","root","fenlei");
        $this->data();

    }

    /**
     * 输出
     */
    function show($id)
    { 
        $this->get_array($id);
        echo $this->format();
    }

    /**
     * 格式化数组
     */
    function format()
    {
        // 此时数组已经得到，通过操作level，我们可以获得自定义的样式
        $str = "";
        $str .= "<select name=''><option>请选择</option>";
        foreach($this->order_data as $key => $val)
        {
            if($val['level'] == 1)
                $space = "";
            else
            {
                $space =str_repeat("│&nbsp;", ($val['level']-1))."├";
            }
            $str .= "<option>".$space.$val['name']."</option>";
        }
        $str .="</select>";
        return $str;
    }

    /**
     * 获取栏目下所有后代栏目
     * @param  int $id 栏目id
     * @return array 
     */
    function get_array($id)
    {
        static $level = 1;
        $res = $this->get_child($id,$level);
        if($level == 1)
            $this->order_data = $res;
        else
            $this->order_data = insert_array($res,$id,$this->order_data);
        if (count($res) > 0)
        {
            $level++;
            foreach($res as $key => $val)
                $this->get_array($val['id']);
            $level--;
        }
    }

    /**
     * 获取对应子栏目
     * @param  int $pid   父id
     * @param  int $level 层级
     * @return array 
     */
    function get_child($pid,$level)
    {
        $res_array = array();
        foreach($this->data as $key => $val)
        {
            if ($val['pid'] == $pid)
            {
                $val['level'] = $level;
                $res_array[$key] = $val;
            }
        }
        return $res_array;
    }

    /**
     * 获取数组
     * @return void 
     */
    function data()
    {
        $sql = "select * from category_1_copy order by list_order desc";
        $res = $this->db->query($sql);
        while($row = $res->fetch_assoc())
            $this->data[$row['id']] = $row;
    }
}

//测试
$demo = new category_1();
$data = $demo->show(0);




