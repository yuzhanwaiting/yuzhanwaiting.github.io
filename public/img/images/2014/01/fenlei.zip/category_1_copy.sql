/*
Navicat MySQL Data Transfer

Source Server         : 本机
Source Server Version : 50611
Source Host           : localhost:3306
Source Database       : fenlei

Target Server Type    : MYSQL
Target Server Version : 50611
File Encoding         : 65001

Date: 2014-01-10 20:19:07
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for category_1_copy
-- ----------------------------
DROP TABLE IF EXISTS `category_1_copy`;
CREATE TABLE `category_1_copy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类id',
  `pid` int(10) unsigned NOT NULL COMMENT '分类父id',
  `name` varchar(30) NOT NULL COMMENT '分类名称',
  `list_order` int(11) NOT NULL DEFAULT '0' COMMENT '分类排序，默认为0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of category_1_copy
-- ----------------------------
INSERT INTO `category_1_copy` VALUES ('1', '0', '新闻', '0');
INSERT INTO `category_1_copy` VALUES ('2', '1', '体育新闻', '0');
INSERT INTO `category_1_copy` VALUES ('3', '1', '社会新闻', '3');
INSERT INTO `category_1_copy` VALUES ('4', '2', 'NBA', '5');
INSERT INTO `category_1_copy` VALUES ('5', '2', '欧冠', '2');
INSERT INTO `category_1_copy` VALUES ('6', '0', '世界', '4');
INSERT INTO `category_1_copy` VALUES ('7', '6', '中东', '0');
INSERT INTO `category_1_copy` VALUES ('8', '6', '欧洲', '6');
INSERT INTO `category_1_copy` VALUES ('9', '8', '俄罗斯', '0');
INSERT INTO `category_1_copy` VALUES ('10', '3', '大楚新闻', '0');
INSERT INTO `category_1_copy` VALUES ('11', '5', '皇马', '0');
